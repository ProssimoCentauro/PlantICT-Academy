package com.academy.ggTournaments;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GgTournamentsApplicationTests {

	@Test
	void contextLoads() {
	}

}
